package com.rucoyvision

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Detector experimental que usa a aparência das barras de HP verdes no screenshot
 * do Rucoy e exclui rótulos azuis de personagens.
 * NÃO comprova que o alvo seja um monstro. Não usar para ações automáticas.
 */
object MobDetector {
    data class Candidate(
        val left: Int,
        val top: Int,
        val width: Int,
        val height: Int
    ) {
        val centerX: Int get() = left + width / 2
        val centerY: Int get() = top + height + 39
    }

    private class Cluster(var left: Int, val top: Int, var lastRow: Int,
                          var count: Int, var longest: Int)

    fun find(bitmap: Bitmap): List<Candidate> {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 200) return emptyList()

        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val minRun = max(18, (w * 0.013).toInt())
        val maxRun = (w * 0.12).toInt()
        val clusters = mutableListOf<Cluster>()

        for (y in (h * 0.10).toInt() until (h * 0.85).toInt()) {
            var x = 0
            while (x < w) {
                if (!isHealthGreen(pixels[y * w + x])) {
                    x++
                    continue
                }
                val startX = x
                do {
                    x++
                } while (x < w && isHealthGreen(pixels[y * w + x]))
                val length = x - startX
                if (length < minRun || length > maxRun) continue

                val sameBar = clusters.firstOrNull {
                    y - it.lastRow <= 2 &&
                    abs(it.left - startX) < max(12, (w * 0.014).toInt())
                }
                if (sameBar == null) {
                    clusters.add(Cluster(startX, y, y, 1, length))
                } else {
                    sameBar.lastRow = y
                    sameBar.count++
                    sameBar.longest = max(sameBar.longest, length)
                    sameBar.left = (sameBar.left + startX) / 2
                }
            }
        }

        val candidates = mutableListOf<Candidate>()
        for (group in clusters) {
            if (group.count < 3 || group.longest < minRun) continue
            if (hasBluePlayerName(pixels, w, h, group)) continue
            candidates.add(Candidate(
                group.left, group.top, group.longest,
                group.lastRow - group.top + 1
            ))
        }
        return candidates.sortedWith(compareBy({ it.top }, { it.left }))
    }

    private fun isHealthGreen(pixel: Int): Boolean {
        val r = pixel shr 16 and 255
        val g = pixel shr 8 and 255
        val b = pixel and 255
        return g in 70..235 && g >= r + 35 && g >= b + 30 && r >= 20
    }

    private fun hasBluePlayerName(pixels: IntArray, w: Int, h: Int,
                                  bar: Cluster): Boolean {
        val startY = max(0, bar.top - (h * 0.045).toInt())
        val endY = max(0, bar.top - (h * 0.010).toInt())
        val startX = max(0, bar.left - 18)
        val endX = min(w, bar.left + bar.longest + 18)
        var blueCount = 0
        for (y in startY until endY) {
            for (x in startX until endX) {
                val pixel = pixels[y * w + x]
                val r = pixel shr 16 and 255
                val g = pixel shr 8 and 255
                val b = pixel and 255
                if (b > 95 && g > 95 && b * 100 > r * 135 && g * 100 > r * 135) {
                    blueCount++
                    if (blueCount > 30) return true
                }
            }
        }
        return false
    }
}
