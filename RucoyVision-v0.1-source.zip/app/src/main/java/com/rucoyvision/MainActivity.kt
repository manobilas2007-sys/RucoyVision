package com.rucoyvision

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.InputStream

/** Analisa screenshots do Rucoy. Nenhuma permissão especial e nenhum controle do jogo. */
class MainActivity : Activity() {
    private lateinit var viewer: ScreenshotView
    private lateinit var status: TextView
    private val requestImage = 27

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 17, 23)
        window.navigationBarColor = Color.rgb(11, 17, 23)

        val background = Color.rgb(13, 20, 27)
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(5), dp(8), dp(5))
            gravity = Gravity.CENTER_VERTICAL
        }
        val label = TextView(this).apply {
            text = "RUCOY VISION 0.1"
            setTextColor(Color.rgb(39, 226, 163))
            setTypeface(null, Typeface.BOLD)
            textSize = 15f
        }
        header.addView(label, LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(button("Abrir print") { openImage() })
        header.addView(button("Detectar") { analyze() })
        header.addView(button("Limpar") {
            viewer.candidates = emptyList()
            status.text = "Marcações ocultas. Use Detectar para ver novamente."
        })
        main.addView(header)

        viewer = ScreenshotView(this)
        main.addView(viewer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(Color.rgb(22, 34, 43))
            text = "Carregando imagem de exemplo..."
        }
        main.addView(status)
        setContentView(main)
        loadExample()
    }

    private fun button(label: String, onTap: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { onTap() }
        }
    }

    private fun loadExample() {
        try {
            assets.open("rucoy_sample.jpg").use { input ->
                loadBitmap(input)
            }
        } catch (e: Exception) {
            status.text = "Não foi possível carregar o print: ${e.message}"
        }
    }

    private fun loadBitmap(input: InputStream) {
        val original = BitmapFactory.decodeStream(input)
            ?: throw IllegalArgumentException("Imagem inválida")
        val maxWidth = 2048
        val bitmap = if (original.width > maxWidth) {
            val scale = maxWidth.toFloat() / original.width
            val resized = Bitmap.createScaledBitmap(original,
                maxWidth, (original.height * scale).toInt(), true)
            original.recycle()
            resized
        } else original
        viewer.bitmap = bitmap
        analyze()
    }

    private fun analyze() {
        val image = viewer.bitmap ?: return
        val found = MobDetector.find(image)
        viewer.candidates = found
        status.text = "${found.size} candidato(s) com barra verde | " +
            "Prévia visual; não controla Rucoy e não garante que sejam monstros."
    }

    private fun openImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, requestImage)
    }

    @Deprecated("Usado para evitar dependências externas no APK de teste")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestImage && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { loadBitmap(it) }
                    ?: throw IllegalArgumentException("Falha ao abrir arquivo")
            } catch (e: Exception) {
                Toast.makeText(this, "Falha: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
