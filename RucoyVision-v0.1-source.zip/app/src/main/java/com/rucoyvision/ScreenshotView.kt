package com.rucoyvision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Desenha o print e as detecções no espaço de coordenadas original da imagem. */
class ScreenshotView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    var candidates: List<MobDetector.Candidate> = emptyList()
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val green = Color.rgb(11, 255, 172)
    private val yellow = Color.rgb(255, 209, 49)
    private val panel = Color.rgb(5, 80, 69)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val image = bitmap ?: return
        val scale = min(width.toFloat() / image.width, height.toFloat() / image.height)
        val leftOffset = (width - image.width * scale) / 2f
        val topOffset = (height - image.height * scale) / 2f

        canvas.save()
        canvas.translate(leftOffset, topOffset)
        canvas.scale(scale, scale)
        paint.color = Color.WHITE
        paint.style = Paint.Style.FILL
        canvas.drawBitmap(image, 0f, 0f, paint)

        val widthBasis = image.width.toFloat()
        val boxHalf = max(48f, widthBasis * 0.037f)
        val tagHeight = max(23f, image.height * 0.040f)
        for ((i, target) in candidates.withIndex()) {
            val x = target.centerX.toFloat()
            val y = target.top.toFloat()

            paint.color = green
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, widthBasis * 0.0018f)
            canvas.drawRoundRect(RectF(x - boxHalf, y - 31f, x + boxHalf, y + 82f),
                9f, 9f, paint)

            paint.color = yellow
            paint.strokeWidth = 2f
            canvas.drawRect(RectF(target.left - 3f, y - 4f,
                target.left + target.width + 3f, y + 11f), paint)

            val tag = "Mob ${i + 1}"
            paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            paint.textSize = max(14f, image.height * 0.025f)
            val textWidth = paint.measureText(tag)
            val tagWidth = textWidth + 16f
            paint.style = Paint.Style.FILL
            paint.color = panel
            canvas.drawRoundRect(RectF(x - tagWidth / 2, y - 33f - tagHeight,
                x + tagWidth / 2, y - 33f), 5f, 5f, paint)
            paint.color = Color.WHITE
            canvas.drawText(tag, x - textWidth / 2, y - 38f, paint)
        }
        canvas.restore()
    }
}
