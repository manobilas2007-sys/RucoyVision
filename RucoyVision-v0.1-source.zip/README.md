# Rucoy Vision v0.1 - Detector visual Android

**Objetivo desta versão:** testar o reconhecimento de possíveis monstros em imagens do Rucoy Online, **sem controlar o jogo**.

## O que funciona
- Abre automaticamente a captura de tela enviada pelo usuário como exemplo.
- Detecta faixas verdes horizontais típicas das barras de HP e marca os candidatos com retângulos.
- Exclui a barra verde associada ao nome azul do jogador na imagem de referência.
- Importa outro screenshot pelo seletor nativo Android, sem acesso irrestrito à galeria.
- Conta os candidatos. Não precisa de internet, root ou permissões especiais no aplicativo.

## Limitações importantes
- O algoritmo identifica **barras verdes**, não entende o mundo do jogo. Outros personagens ou elementos visuais podem ser confundidos com monstros.
- Monstros sem barra verde visível, com HP muito baixo ou sob outros elementos podem não aparecer.
- Esta versão não tem OCR nem identificação confiável da espécie, não captura a tela ao vivo e NÃO gera toques, golpes ou movimentos.
- A validação manual é obrigatória antes de considerar integração de automação, e automação no MMORPG pode violar as regras do jogo.

## Criar APK diretamente no GitHub (sem PC)
1. Crie um repositório GitHub novo (pode ser privado), por exemplo `RucoyVision`.
2. Descompacte o ZIP e envie **o conteúdo** da pasta `RucoyVision-v0.1` para a raiz do repositório, mantendo `.github/workflows/build-apk.yml` e `app/...`.
3. Entre em **Actions > Build APK Rucoy Vision > Run workflow**. A compilação também roda ao enviar para branch main/master.
4. Ao terminar, entre no workflow, abra **Artifacts**, baixe `rucoy-vision-v0.1-debug-apk.zip`, extraia e instale `app-debug.apk` no Android.
5. Abra o app: ele exibirá os cinco candidatos da imagem de exemplo. Use **Abrir print** para escolher outra captura do Rucoy e **Detectar** para atualizar as marcações.

O workflow usa Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, Android SDK 35 e Java 17. Não foi possível compilar o APK localmente neste ambiente por falta do Android SDK/Gradle, portanto o funcionamento final dependerá da execução bem-sucedida do GitHub Actions.

## Estrutura
- `MobDetector.kt`: pixel scanning e filtragem de nomes azuis.
- `ScreenshotView.kt`: desenha caixas sobre o screenshot.
- `MainActivity.kt`: seleção de arquivo, interface e contagem.
- `.github/workflows/build-apk.yml`: compilação do APK no GitHub.
- `app/src/main/assets/rucoy_sample.jpg`: screenshot para demonstrar o algoritmo.

## Privacidade
O detector de screenshots é local. Nenhuma captura é enviada para servidores pelo aplicativo.
